from setuptools import setup

setup(name='mshow',
      version='0.1',
      description='The funniest joke in the world',
      url='https://github.com/nishantsinghdev/mshow',
      author='Nishant Singh',
      author_email='nishant@example.com',
      license='MIT',
      packages=['mshow'],
      zip_safe=False)
